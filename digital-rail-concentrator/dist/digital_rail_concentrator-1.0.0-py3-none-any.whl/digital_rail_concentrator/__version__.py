"""
This module holds the version of digital-rail-concentrator.

It contains a placeholder for the version number, which is replaced by the build script.
"""

VERSION = '1.0.0'
